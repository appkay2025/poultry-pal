# 📝 Release vX.Y.Z

## 🚀 Features
- ✨ New functionality or improvements go here.  
- Example: *Added role-based menus with dynamic visibility.*  

## 🐛 Fixes
- 🔧 Bug fixes and patches go here.  
- Example: *Fixed incorrect report totals when using date filters.*  

## ⚠️ Breaking Changes
- 🚨 Anything that requires user action or migration.  
- Example: *Database schema updated — run `npx prisma migrate deploy` after upgrading.*  

## 📊 Reports & Docs
- 📈 Summary of new reports, dashboards, or docs updates.  
- Example: *New Compare Mode added to Reports module.*  

## ✅ Misc
- 🧹 Refactoring, dependency bumps, CI/CD tweaks, etc.  
- Example: *Added matrix builds for Node 16, 18, 20 in CI.*  

---

### 🔗 Links
- [Changelog](./CHANGELOG.md)  
- [Contribution Guidelines](./CONTRIBUTING.md)  
- [Security Policy](./SECURITY.md)  
