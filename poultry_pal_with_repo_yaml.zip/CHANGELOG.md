# Changelog

All notable changes to this project will be documented in this file.  
This project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]
- Add future planned features here.

## [1.0.0] - 2025-09-24
### Added
- Initial release of **PoultryPal** 🎉
- Authentication & Role-Based Access Control (RBAC).
- User management: register, login, list, promote/demote, delete users.
- Poultry modules: chickens, eggs, feed, medication, expenses, sales, reports.
- Reports with charts, tables, filters, comparisons, and exports (PDF/Excel).
- Deployment configs for Render, Vercel, and Netlify.
- GitHub Actions CI/CD workflow for auto-deployments.
- README with badges (GitHub Actions, Netlify, Vercel, Shields.io).
- LICENSE (MIT), CONTRIBUTING.md, CODE_OF_CONDUCT.md, SECURITY.md.
- Issue templates and pull request template.

---

