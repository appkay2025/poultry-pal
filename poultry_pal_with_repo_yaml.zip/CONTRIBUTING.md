# Contributing to PoultryPal 🐓📊

We’re excited that you want to contribute to **PoultryPal**! 🎉  
Your help makes this project better for everyone.  

## How to Contribute

### 1. Fork and Clone
- Fork this repository.
- Clone your fork locally.

### 2. Create a Branch
```bash
git checkout -b feature/your-feature-name
```

### 3. Make Changes
- Add your code or documentation changes.
- Follow existing code style and structure.

### 4. Commit
```bash
git commit -m "Add: description of feature or fix"
```

### 5. Push and Open PR
- Push your branch.
- Open a Pull Request (PR) to the `main` branch.

---

## Contribution Guidelines
- Use clear commit messages.
- Write clean, readable code.
- Add tests where relevant.
- Keep PRs focused — one feature/fix per PR.

---

## Community
- Be respectful and constructive.
- Collaborate openly — suggestions and feedback are welcome!

---

Thank you for helping improve PoultryPal! ❤️
