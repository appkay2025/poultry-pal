# 🐔 PoultryPal — Smart Poultry Farm Management  

[![Deploy](https://github.com/YOUR_USERNAME/poultry-pal/actions/workflows/deploy.yml/badge.svg)](https://github.com/YOUR_USERNAME/poultry-pal/actions/workflows/deploy.yml)  
[![Netlify Status](https://api.netlify.com/api/v1/badges/YOUR_NETLIFY_ID/deploy-status)](https://app.netlify.com/sites/YOUR_SITE/deploys)  
[![Vercel Status](https://vercelbadge.vercel.app/api/YOUR_USERNAME/poultry-pal)](https://vercel.com/YOUR_USERNAME/poultry-pal)  
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](./LICENSE)  
[![GitHub release (latest by date)](https://img.shields.io/github/v/release/YOUR_USERNAME/poultry-pal?style=for-the-badge)](https://github.com/YOUR_USERNAME/poultry-pal/releases)  
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](./CONTRIBUTING.md)  

---

## 🌟 Features  
- 📊 **Inventory Tracking** — Manage chickens, eggs, feed, medications, sales, and expenses.  
- 🧾 **Custom Categories** — Setup expense types, income categories, feed types, and disease tracking.  
- 📈 **Reports & Analytics** — Generate tables, charts, and downloadable PDF/Excel reports.  
- ⏳ **Date Filters & Quick Filters** — Filter reports by range, preset periods, and compare timeframes.  
- 🔐 **Authentication & Roles** — Admins, workers, and managers with role-based dashboards.  
- 🛠 **User Management** — Admins can register, promote/demote, or remove users.  
- ☁️ **Deployment Ready** — Pre-configured for Render (backend) and Vercel/Netlify (frontend).  

---

## 🚀 Installation  

### Prerequisites  
- Node.js (16, 18, or 20)  
- npm (v8+)  
- PostgreSQL (for Prisma)  

### Clone & Install  
```bash
git clone https://github.com/YOUR_USERNAME/poultry-pal.git
cd poultry-pal
```

#### Backend  
```bash
cd backend
npm install
npx prisma migrate dev
npm run dev
```

#### Frontend  
```bash
cd frontend
npm install
npm start
```

---

## 🔑 Authentication & Roles  
- **Admin** — Full access, user management, reports.  
- **Manager** — Manage inventory, sales, expenses, medications.  
- **Worker** — Limited to feeding, recording eggs/chickens.  

---

## 📊 Reports & Exports  
- Charts + tables per category  
- PDF/Excel export with date range filtering  
- Compare mode for period-to-period analysis  

---

## 🧑‍💻 Contributing  
We welcome contributions! 🙌  
See [CONTRIBUTING.md](./CONTRIBUTING.md) for setup and guidelines.  

Please also follow our [Code of Conduct](./CODE_OF_CONDUCT.md).  

---

## 🔒 Security  
If you discover a vulnerability, please follow our [Security Policy](./SECURITY.md).  

---

## 📜 License  
This project is licensed under the [MIT License](./LICENSE).  

---

## 📦 Changelog  
See [CHANGELOG.md](./CHANGELOG.md) for version history and updates.  
