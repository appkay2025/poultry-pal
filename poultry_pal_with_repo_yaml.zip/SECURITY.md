# Security Policy

## Supported Versions
We release patches for security vulnerabilities as needed.  
Only the latest version of **PoultryPal** is currently supported.  

| Version | Supported          |
| ------- | ------------------ |
| latest  | :white_check_mark: |
| older   | :x:                |

## Reporting a Vulnerability
If you discover a security vulnerability in this project, please help us by reporting it responsibly:

1. **Do not create a public GitHub issue.**
2. Instead, email the maintainers at: **security@example.com** (replace with your contact email).
3. Provide a detailed description of the issue, including steps to reproduce if possible.
4. We will acknowledge receipt within 48 hours and strive to provide a fix within a reasonable timeframe.

## Best Practices for Users
- Keep your deployment dependencies up to date.
- Always rotate secrets (API keys, JWT secrets, DB passwords) periodically.
- Use HTTPS for production deployments.

Thank you for helping keep **PoultryPal** and its community secure! 🔐
